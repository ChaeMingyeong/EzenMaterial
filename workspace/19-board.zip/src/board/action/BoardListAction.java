package board.action;

public class BoardListAction {
       
}
