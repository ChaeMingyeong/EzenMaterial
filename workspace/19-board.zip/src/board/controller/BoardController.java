package board.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import board.action.Action;
import board.action.BoardWriteProAction;


@WebServlet("*.do") //끝에 .do인 파일만 반응하게끔  
public class BoardController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
    public BoardController() {
        super();
     
    }
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		process(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {	
		process(request, response);
	}
	
	protected void process(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {	
        request.setCharacterEncoding("UTF-8");	
        //요청정보확인
        String command = request.getServletPath();
        System.out.println("command = " + command);
        /** 데이터 처리 */
        //요청작업처리
        String message = null;
        String forward = null; //view 처리용 jsp 파일 이름 저장 
        Action action = null;
       
       
        
        
        message = request.getParameter("message");
        
        if(command.equals("/boardWriteForm.do")) {
        	forward = "/board/boardWriteForm.jsp";
        }else if(command.equals("boardWritePro.do")) {
        
        	action = new BoardWriteProAction();
        	// forward = "/board/boardList.jsp";
        }
        
        
      
       System.out.println("message: " + message );
      
       if(action !=null) {
      	 try {
				forward = action.process(request, response);
			} catch (Throwable e) {
				
				e.printStackTrace();
			}
        
      }
           
        
        /** view 처리(HTML 작업)*/
        if(forward!=null) {
        	RequestDispatcher dispatcher = request.getRequestDispatcher(forward);
        	dispatcher.forward(request, response);
        }
	}

}
